import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show',
  templateUrl: './show.page.html',
  styleUrls: ['./show.page.scss'],
})
export class ShowPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  slideOpts = {
    initialSlide: 1,
    speed: 400
  };

}
