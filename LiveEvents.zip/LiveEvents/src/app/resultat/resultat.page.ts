import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultat',
  templateUrl: './resultat.page.html',
  styleUrls: ['./resultat.page.scss'],
})
export class ResultatPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }



  option3 = {
    slidesPerView: 1.5,
    centeredSlides:true,
    loop:true,
    spaceBetween:10,
    autoplay:true,
  }
  
}
